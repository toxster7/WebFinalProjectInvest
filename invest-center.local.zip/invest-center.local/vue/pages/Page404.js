"use strict";

const Page404 = {
	
	data: function () {
		return {
			
		}
	},	
	
	computed: {
	
		
	},
	
	methods: {
		
	
		
	},

	template: `	


<div class="content d-flex justify-content-center align-items-center">

	<!-- Container -->
	<div class="flex-fill">

		<!-- Error title -->
		<div class="text-center mb-3">
			<h1 class="error-title">404</h1>
			<h5>Oops, an error has occurred. Page not found!</h5>
		</div>
		<!-- /error title -->

	</div>
	<!-- /container -->

</div>
	`
	
};
